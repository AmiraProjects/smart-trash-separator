function trash() {
  //trash sorting function
  var organic = [
    "Fruit skin",
    "Vegetable peel",
    "Food leftovers",
    "Tea bags",
    "Fish bones",
    "Meats",
    "Leaves",
    "Flowers",
  ];
  var inorganic = [
    "Paper",
    "Plastic bag",
    "Bottle",
    "Masks",
    "Cardboard",
    "Straw",
    "Plastic cup",
    "Rubber bands",
    "Tissues",
  ];
  var metal = ["Can", "Aluminium", "Steel", "Battery", "Wire"];
  var userValue = document.getElementById("userInput").value.trim(); // Trim whitespace
  var li = document.createElement("li");

  if (userValue === "") {
    alert("Must Fill Text");
    return; // Stop execution if the input is empty
  }

  if (organic.includes(userValue)) {
    document
      .getElementById("organicUl")
      .appendChild(li)
      .setAttribute("class", "organic-trash-item");
    li.innerHTML = userValue;
  } else if (inorganic.includes(userValue)) {
    document
      .getElementById("inorganicUl")
      .appendChild(li)
      .setAttribute("class", "inorganic-trash-item");
    li.innerHTML = userValue;
  } else if (metal.includes(userValue)) {
    document
      .getElementById("metalUl")
      .appendChild(li)
      .setAttribute("class", "metal-trash-item");
    li.innerHTML = userValue;
  } else {
    alert("Trash type not recognized");
  }

  document.getElementById("userInput").value = ""; // Clear the input box after processing
}

var slides = document.querySelectorAll(".slide");
var buttons = document.querySelectorAll(".slider-btn");
let currentSlide = 1;

var manualNav = function (manual) {
  slides.forEach(function (slide) {
    slide.classList.remove("active");

    buttons.forEach((btn) => {
      btn.classList.remove("active");
    });
  });

  slides[manual].classList.add("active");
  buttons[manual].classList.add("active");
};

buttons.forEach(function (btn, i) {
  btn.addEventListener("click", function () {
    manualNav(i);
    currentSlide = i;
  });
});

var repeat = function (activeClass) {
  let active = document.getElementsByClassName("active");

  let i = 1;
  var repeater = function () {
    setTimeout(function () {
      [...active].forEach(function (activeSlide) {
        activeSlide.classList.remove("active");
      });

      slides[i].classList.add("active");
      buttons[i].classList.add("active");
      i++;

      if (slides.length == i) {
        i = 0;
      }
      if (i >= slides.length) {
        return;
      }
      repeater();
    }, 5000);
  };
  repeater();
};
repeat();

function changeImageOrganic(element) {
  element.setAttribute("src", "assets/tempat sampah organik.png");
}
function changeImageBackOrganic(element) {
  element.setAttribute("src", "assets/tempat sampah organik 1.png");
}
function changeImageInorganic(element) {
  element.setAttribute("src", "assets/tempat sampah inorganik 1.png");
}
function changeImageBackInorganic(element) {
  element.setAttribute("src", "assets/tempat sampah inorganik.png");
}
function changeImageMetal(element) {
  element.setAttribute("src", "assets/tempat sampah metal 1.png");
}
function changeImageBackMetal(element) {
  element.setAttribute("src", "assets/tempat sampah metal.png");
}
function changeImage(element) {
  element.setAttribute("src", "assets/gunung sampah 1.jpg");
}
function changeImageBack(element) {
  element.setAttribute("src", "assets/gunung sampah.jpg");
}

var btnSubmit = document.querySelector(".submit");
var modal = document.querySelector(".modal-container");

if (btnSubmit) {
  btnSubmit.addEventListener("click", function () {
    modal.classList.add("show");

    const next = document.querySelector(".next");
    next.setAttribute(
      "value",
      "https://smart-trash-separator-amira.netlify.app/contact.html",
    );
  });
}

window.addEventListener("scroll", reveal);

function reveal() {
  var reveals = document.querySelectorAll(".reveal");

  reveals.forEach((reveal) => {
    var windowHeight = window.innerHeight;
    var revealTop = reveal.getBoundingClientRect().top;
    var revealPoint = 40;

    if (revealTop < windowHeight - revealPoint) {
      reveal.classList.add("active");
    } else {
      reveal.classList.remove("active");
    }
  });
}
